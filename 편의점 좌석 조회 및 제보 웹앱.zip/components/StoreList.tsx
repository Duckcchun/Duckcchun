// 이 파일은 현재 사용되지 않습니다.
// ConvenienceStoreList 컴포넌트를 사용하고 있습니다.
export {};